# Hotel reservation

Application developed in the context of:
https://docs.lightweightform.io/tutorial
